# Papa ❤ Chlm

A private little Android app for two people, built as two separate app flavors
from one project: **chlm** and **papa**. Rebuilt clean from your two old
APKs, keeping the same idea, plus a few real upgrades.

## How to build (no unzipping needed on your phone)

You don't need to extract the zip on your phone at all — just upload these
files to your GitHub repo exactly as they are:

1. **Upload the whole `papachlm-love-project.zip` file as-is** to the repo
   root (Add file → Upload files → pick the zip from Downloads).
2. **Upload `google-services.json` as-is** to the repo root too, once you've
   done the Firebase steps below (also just a plain file upload).
3. Create one new text file: **Add file → Create new file**, type this as
   the filename (GitHub creates the folders for you):
   `.github/workflows/build-apk.yml`
   then paste in the workflow text from `.github/workflows/build-apk.yml`
   inside the zip (open it in Files app to view/copy the text, or ask for it
   to be pasted directly in chat).
4. Commit. Actions will unzip the project itself on GitHub's servers and
   build both APKs — nothing to extract on your end.

Download the finished APKs from the Actions run's "Artifacts" section:
`app-chlm-release-unsigned`, `app-papa-release-unsigned`.

## ⚠️ One-time setup needed before this builds: Firebase

Chat now syncs between both phones in real time using Firebase (free). The
build will **fail** until you do this once:

1. Go to https://console.firebase.google.com → **Add project** → give it any
   name → finish creating it.
2. In the project, click **Build → Realtime Database → Create Database**
   (any region is fine). This gives the project a database URL.
3. Still in Realtime Database, go to the **Rules** tab and paste:
   ```json
   { "rules": { ".read": true, ".write": true } }
   ```
   then **Publish**. (This means anyone who somehow found your database's
   private URL could read/write it — fine for a private couple app, just
   good to know it isn't bank-grade security.)
4. Click the gear icon → **Project settings** → scroll to **Your apps** →
   click the Android icon → **Add app**, and register it twice, once for
   each package name:
   - `com.papachlm.love.chlm`
   - `com.papachlm.love.papa`
5. After adding both, download **google-services.json** (it covers both
   apps in one file). Don't put it inside the zip — upload it as its own
   separate file straight to your GitHub repo root (see build steps above).

## What's in this version

- **Pairing** — same shared code idea as before (default `312026`, change it
  in `app/build.gradle` under `buildConfigField "String", "PAIRING_CODE"`
  before building — both flavors always share the same code since they're
  built together).
- **Chat** — write sweet messages, little heart animation on send. Messages
  now sync between both phones in real time through Firebase (see setup
  above), and still work offline — they send the moment internet comes back.
- **Voice messages** — your two original recordings are carried over
  (`res/raw/papa_voice.m4a`, `res/raw/chlm_voice.m4a`). I couldn't tell which
  recording is which person's voice just from the file — listen and swap the
  file names if they're backwards. You can also record new voice notes
  directly in the app now (tap the mic button) — these are saved locally too.
- **Call** — the old call screen only showed a "backend required" message and
  didn't actually call anyone. This version replaces it with something that
  actually works: a **Voice call** button opens your phone dialer, and a
  **Video call** button opens a WhatsApp chat with your partner's number so
  you can tap WhatsApp's own call button. Set the partner's number once under
  Settings.
- **Settings** — set partner's phone number, see your own role, reset
  pairing to test the pairing screen again.

## Known limits (not built yet)

- Voice notes you record in-app still stay on that phone only (not synced) —
  only the text chat syncs for now.
- There's no true in-app video/voice calling (WebRTC) — that needs a
  signaling server and real device testing to get right, so instead the app
  hands off to your phone dialer / WhatsApp, which is simpler and reliable.
- No push notification when the other person sends a message while the app
  is closed — you'd need to open the app to see new messages.

## Project layout

```
app/src/main/java/com/papachlm/love/
  MainActivity.kt      – all screens (pairing, chat, voice, call, settings)
  Prefs.kt             – saved settings (paired?, partner's number)
  ChatRepository.kt    – Firebase-backed chat sync
  VoiceStore.kt        – local recorded voice note storage
  PapaChlmApp.kt       – turns on offline caching for chat
app/src/main/res/
  raw/                 – the two voice message files
  drawable/couple_photo.jpg – your photo, shown on the Voice tab
google-services.json – YOU upload this to the repo root (see setup above);
                       the workflow copies it into app/ automatically
```
