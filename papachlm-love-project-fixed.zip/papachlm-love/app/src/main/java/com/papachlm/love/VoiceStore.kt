package com.papachlm.love

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class VoiceNote(val fileName: String, val label: String, val timestamp: Long)

/**
 * Recorded voice notes are stored as .m4a files under filesDir/voice_notes/,
 * with a small JSON index alongside them. This is separate from the two
 * bundled default voice messages (res/raw/papa_voice.m4a, chlm_voice.m4a).
 */
object VoiceStore {
    private const val INDEX_FILE = "voice_notes.json"
    private const val DIR = "voice_notes"

    fun dir(ctx: Context): File {
        val d = File(ctx.filesDir, DIR)
        if (!d.exists()) d.mkdirs()
        return d
    }

    private fun indexFile(ctx: Context) = File(ctx.filesDir, INDEX_FILE)

    fun list(ctx: Context): List<VoiceNote> {
        val f = indexFile(ctx)
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                VoiceNote(o.getString("fileName"), o.getString("label"), o.getLong("timestamp"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun add(ctx: Context, note: VoiceNote) {
        val current = list(ctx).toMutableList()
        current.add(note)
        val arr = JSONArray()
        current.forEach {
            val o = JSONObject()
            o.put("fileName", it.fileName)
            o.put("label", it.label)
            o.put("timestamp", it.timestamp)
            arr.put(o)
        }
        indexFile(ctx).writeText(arr.toString())
    }

    fun newFileFor(ctx: Context, timestamp: Long): File =
        File(dir(ctx), "note_$timestamp.m4a")
}
