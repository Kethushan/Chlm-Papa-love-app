package com.papachlm.love

import android.app.Application
import com.google.firebase.database.FirebaseDatabase

class PapaChlmApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Must be called before any other FirebaseDatabase usage, and only once.
        // Lets chat still work with no internet — it syncs once back online.
        try {
            FirebaseDatabase.getInstance().setPersistenceEnabled(true)
        } catch (e: Exception) {
            // Already enabled or Firebase not yet configured — safe to ignore.
        }
    }
}
