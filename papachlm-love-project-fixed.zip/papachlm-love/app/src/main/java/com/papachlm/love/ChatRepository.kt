package com.papachlm.love

import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

// Firebase needs a no-arg constructor to read this back automatically,
// which is why every property has a default value.
data class ChatMessage(
    val sender: String = "",
    val text: String = "",
    val timestamp: Long = 0L
)

/**
 * Both phones are built from the same PAIRING_CODE, so that code doubles as
 * a shared "room" name in the database — no login/auth needed for this to work.
 * Requires app/google-services.json from your own Firebase project (see README).
 */
object ChatRepository {

    private fun roomRef(): DatabaseReference =
        FirebaseDatabase.getInstance()
            .reference
            .child("rooms")
            .child(BuildConfig.PAIRING_CODE)
            .child("messages")

    fun send(message: ChatMessage) {
        roomRef().push().setValue(message)
    }

    /** Call once. Fires for every message already in the room, then for each new one. */
    fun listen(onMessage: (ChatMessage) -> Unit): ChildEventListener {
        val ref = roomRef()
        ref.keepSynced(true)
        val listener = object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                snapshot.getValue(ChatMessage::class.java)?.let(onMessage)
            }
            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {}
            override fun onChildRemoved(snapshot: DataSnapshot) {}
            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {}
            override fun onCancelled(error: DatabaseError) {}
        }
        ref.addChildEventListener(listener)
        return listener
    }

    fun stopListening(listener: ChildEventListener) {
        roomRef().removeEventListener(listener)
    }
}
