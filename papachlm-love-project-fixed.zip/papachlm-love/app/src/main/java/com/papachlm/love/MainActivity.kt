package com.papachlm.love

import android.content.ActivityNotFoundException
import android.content.Intent
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.firebase.database.ChildEventListener
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var contentFrame: FrameLayout
    private lateinit var tabBar: LinearLayout

    private var mediaPlayer: MediaPlayer? = null
    private var mediaRecorder: MediaRecorder? = null
    private var isRecording = false
    private var pendingRecordingFile: File? = null

    // Filled in by Firebase as messages arrive (both old ones and new ones live).
    private val chatMessages = mutableListOf<ChatMessage>()
    private var chatListener: ChildEventListener? = null
    private var onNewChatMessage: (() -> Unit)? = null

    private val requestMicPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startRecording() else
            Toast.makeText(this, R.string.voice_permission_needed, Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        contentFrame = findViewById(R.id.content_frame)
        tabBar = findViewById(R.id.tab_bar)

        chatListener = ChatRepository.listen { msg ->
            chatMessages.add(msg)
            onNewChatMessage?.invoke()
        }

        if (Prefs.isPaired(this)) {
            showTabs()
            showChat()
        } else {
            showPairScreen()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.release()
        mediaRecorder?.release()
        chatListener?.let { ChatRepository.stopListening(it) }
    }

    // ---------- Pairing ----------

    private fun showPairScreen() {
        onNewChatMessage = null
        tabBar.visibility = View.GONE
        val v = LayoutInflater.from(this).inflate(R.layout.view_pair, contentFrame, false)
        contentFrame.removeAllViews()
        contentFrame.addView(v)

        val message = v.findViewById<TextView>(R.id.pair_message)
        val codeDisplay = v.findViewById<TextView>(R.id.pair_code_display)
        val codeInput = v.findViewById<EditText>(R.id.pair_code_input)
        val actionButton = v.findViewById<Button>(R.id.pair_action_button)

        val partnerName = Prefs.partnerRole.replaceFirstChar { it.uppercase() }

        if (Prefs.myRole == "papa") {
            message.text = getString(R.string.pair_give_code, partnerName)
            codeDisplay.text = BuildConfig.PAIRING_CODE
            codeDisplay.visibility = View.VISIBLE
            actionButton.text = getString(R.string.pair_continue)
            actionButton.setOnClickListener {
                Prefs.setPaired(this, true)
                showTabs()
                showChat()
            }
        } else {
            message.text = getString(R.string.pair_enter_code, partnerName)
            codeInput.visibility = View.VISIBLE
            actionButton.text = getString(R.string.pair_button)
            actionButton.setOnClickListener {
                if (codeInput.text.toString().trim() == BuildConfig.PAIRING_CODE) {
                    Prefs.setPaired(this, true)
                    showTabs()
                    showChat()
                } else {
                    Toast.makeText(this, R.string.pair_wrong_code, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // ---------- Tab bar ----------

    private fun showTabs() {
        tabBar.visibility = View.VISIBLE
        findViewById<TextView>(R.id.tab_chat).setOnClickListener { showChat() }
        findViewById<TextView>(R.id.tab_voice).setOnClickListener { showVoice() }
        findViewById<TextView>(R.id.tab_call).setOnClickListener { showCall() }
        findViewById<TextView>(R.id.tab_settings).setOnClickListener { showSettings() }
    }

    private fun swapContent(layoutRes: Int): View {
        onNewChatMessage = null
        val v = LayoutInflater.from(this).inflate(layoutRes, contentFrame, false)
        contentFrame.removeAllViews()
        contentFrame.addView(v)
        return v
    }

    // ---------- Chat ----------

    private fun showChat() {
        val v = swapContent(R.layout.view_chat)
        val container = v.findViewById<LinearLayout>(R.id.chat_container)
        val scroll = v.findViewById<ScrollView>(R.id.chat_scroll)
        val input = v.findViewById<EditText>(R.id.chat_input)
        val send = v.findViewById<Button>(R.id.chat_send)
        val heart = v.findViewById<ImageView>(R.id.heart_burst)

        fun render() {
            container.removeAllViews()
            chatMessages.forEach { msg -> container.addView(buildBubble(msg)) }
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
        onNewChatMessage = { render() }
        render()

        send.setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener
            ChatRepository.send(ChatMessage(Prefs.myRole, text, System.currentTimeMillis()))
            input.setText("")
            burstHeart(heart)
            // The bubble for this message appears once Firebase echoes it back
            // via onNewChatMessage — instantly, even offline, thanks to local caching.
        }
    }

    private fun buildBubble(msg: ChatMessage): View {
        val isMine = msg.sender == Prefs.myRole
        val row = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            gravity = if (isMine) Gravity.END else Gravity.START
            setPadding(0, 6, 0, 6)
        }
        val bubble = TextView(this).apply {
            text = msg.text
            setTextColor(ContextCompat.getColor(this@MainActivity, if (isMine) R.color.text_light else R.color.text_dark))
            setBackgroundResource(if (isMine) R.drawable.bubble_self else R.drawable.bubble_other)
            setPadding(28, 18, 28, 18)
            textSize = 15f
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            layoutParams = lp
        }
        row.addView(bubble)
        return row
    }

    private fun burstHeart(heart: ImageView) {
        heart.alpha = 1f
        heart.scaleX = 0.3f
        heart.scaleY = 0.3f
        heart.visibility = View.VISIBLE
        heart.animate()
            .scaleX(1.4f).scaleY(1.4f).alpha(0f)
            .setDuration(700)
            .withEndAction { heart.visibility = View.INVISIBLE }
            .start()
    }

    // ---------- Voice ----------

    private fun showVoice() {
        val v = swapContent(R.layout.view_voice)
        val list = v.findViewById<LinearLayout>(R.id.voice_list)
        val recordButton = v.findViewById<Button>(R.id.voice_record_button)

        fun render() {
            list.removeAllViews()
            list.addView(voiceRow("Papa's voice message") { playRaw(R.raw.papa_voice) })
            list.addView(voiceRow("Chlm's voice message") { playRaw(R.raw.chlm_voice) })
            VoiceStore.list(this).forEach { note ->
                list.addView(voiceRow(note.label) { playFile(File(VoiceStore.dir(this), note.fileName)) })
            }
        }
        render()

        recordButton.setOnClickListener {
            if (isRecording) {
                stopRecording()
                recordButton.text = getString(R.string.voice_record_new)
                render()
            } else {
                if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO)
                    == android.content.pm.PackageManager.PERMISSION_GRANTED
                ) {
                    startRecording()
                    recordButton.text = getString(R.string.voice_recording)
                } else {
                    requestMicPermission.launch(android.Manifest.permission.RECORD_AUDIO)
                }
            }
        }
    }

    private fun voiceRow(label: String, onPlay: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setPadding(0, 10, 0, 10)
        }
        val text = TextView(this).apply {
            text = label
            textSize = 15f
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_dark))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            gravity = Gravity.CENTER_VERTICAL
        }
        val playButton = Button(this).apply {
            text = "▶ Play"
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_light))
            setBackgroundResource(R.drawable.btn_round)
            setOnClickListener { onPlay() }
        }
        row.addView(text)
        row.addView(playButton)
        return row
    }

    private fun playRaw(resId: Int) {
        mediaPlayer?.release()
        mediaPlayer = MediaPlayer.create(this, resId)?.apply { start() }
    }

    private fun playFile(file: File) {
        mediaPlayer?.release()
        mediaPlayer = MediaPlayer().apply {
            setDataSource(file.absolutePath)
            prepare()
            start()
        }
    }

    private fun startRecording() {
        val timestamp = System.currentTimeMillis()
        val outFile = VoiceStore.newFileFor(this, timestamp)
        pendingRecordingFile = outFile
        mediaRecorder = MediaRecorder().apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setOutputFile(outFile.absolutePath)
            prepare()
            start()
        }
        isRecording = true
    }

    private fun stopRecording() {
        try {
            mediaRecorder?.stop()
        } catch (e: Exception) {
            // Recording was too short or failed; drop the partial file.
        }
        mediaRecorder?.release()
        mediaRecorder = null
        isRecording = false

        val file = pendingRecordingFile
        if (file != null && file.exists() && file.length() > 0) {
            val label = "Voice note – " + SimpleDateFormat("d MMM, h:mm a", Locale.getDefault())
                .format(Date())
            VoiceStore.add(this, VoiceNote(file.name, label, System.currentTimeMillis()))
        }
        pendingRecordingFile = null
    }

    // ---------- Call ----------

    private fun showCall() {
        val v = swapContent(R.layout.view_call)
        val voiceButton = v.findViewById<Button>(R.id.call_voice_button)
        val videoButton = v.findViewById<Button>(R.id.call_video_button)

        voiceButton.setOnClickListener {
            val phone = Prefs.partnerPhone(this)
            if (phone.isBlank()) {
                Toast.makeText(this, R.string.call_no_number, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")))
        }

        videoButton.setOnClickListener {
            val phone = Prefs.partnerPhone(this)
            if (phone.isBlank()) {
                Toast.makeText(this, R.string.call_no_number, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val digits = phone.filter { it.isDigit() }
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$digits"))
                intent.setPackage("com.whatsapp")
                startActivity(intent)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(this, R.string.call_no_whatsapp, Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------- Settings ----------

    private fun showSettings() {
        val v = swapContent(R.layout.view_settings)
        val roleText = v.findViewById<TextView>(R.id.settings_role_text)
        val numberInput = v.findViewById<EditText>(R.id.settings_partner_number)
        val saveButton = v.findViewById<Button>(R.id.settings_save_button)
        val unpairButton = v.findViewById<Button>(R.id.settings_unpair_button)

        roleText.text = getString(R.string.settings_role) + ": " +
            Prefs.myRole.replaceFirstChar { it.uppercase() }
        numberInput.setText(Prefs.partnerPhone(this))

        saveButton.setOnClickListener {
            Prefs.setPartnerPhone(this, numberInput.text.toString().trim())
            Toast.makeText(this, R.string.settings_saved, Toast.LENGTH_SHORT).show()
        }

        unpairButton.setOnClickListener {
            Prefs.setPaired(this, false)
            showPairScreen()
        }
    }
}
