package com.papachlm.love

import android.content.Context

/**
 * Small wrapper around SharedPreferences.
 * MY_ROLE / PARTNER_ROLE come from BuildConfig, baked in per flavor (chlm or papa),
 * so the same source code produces two personalised apps.
 */
object Prefs {
    private const val FILE = "papachlm_prefs"
    private const val KEY_PAIRED = "paired"
    private const val KEY_PARTNER_PHONE = "partner_phone"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    val myRole: String get() = BuildConfig.MY_ROLE
    val partnerRole: String get() = BuildConfig.PARTNER_ROLE

    fun isPaired(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_PAIRED, false)

    fun setPaired(ctx: Context, value: Boolean) {
        prefs(ctx).edit().putBoolean(KEY_PAIRED, value).apply()
    }

    fun partnerPhone(ctx: Context): String = prefs(ctx).getString(KEY_PARTNER_PHONE, "") ?: ""

    fun setPartnerPhone(ctx: Context, phone: String) {
        prefs(ctx).edit().putString(KEY_PARTNER_PHONE, phone).apply()
    }
}
